### Обновление системы
`sudo apt update && sudo apt upgrade -y`
### Смена языка на Alt + Shift
`gsettings set org.gnome.desktop.input-sources xkb-options "['grp:alt_shift_toggle']"`
### Смена разрешения экрана
```bash
sudo nano /etc/defualt/grub
```
```/etc/defualt/grub
GRUB_CMDLINE_LINUX_DEFAULT="quiet splash video=hyperv_fb:1920x1080"
```
```bash
sudo update-grub
sudo reboot
```

