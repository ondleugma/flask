### Обновление индексов пакетов apt
`sudo apt update`
### Установка веб-сервера Apache 2
`sudo apt install apache2 -y`
### Запуск и автозагрузка Apache 2
```bash
sudo systemctl start apache2
sudo systemctl enable apache2
```
### Проверка установки сервера Apache 2
`service apache2 status`

![[Pasted image 20241108141710.png | 500]]

### Проверка включения файрвола UFW
`sudo ufw status`

![[Pasted image 20241108141845.png | 500]]

### Включение файрвола UFW, если не active
`sudo ufw enable`
### Разрешение доступа к порту 80 через UFW
`sudo ufw allow 80`
### Если нужен https, то порт 443 тоже
`sudo ufw allow 443`
### Проверка работы
Зайти на http://127.0.0.1.

![[Pasted image 20241108142530.png | 500]]

---
[Источник](https://timeweb.cloud/tutorials/ubuntu/ustanovka-i-nastrojka-apache-na-ubuntu)
