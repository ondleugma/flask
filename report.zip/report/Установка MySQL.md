### Обновление индексов пакетов apt
`sudo apt update`
### Установка пакета по умолчанию
`sudo apt install mysql-server`
## Настройка MySQL
### Запустите скрипт безопасности
`sudo mysql_secure_installation`
###
``

---
[Источник](https://timeweb.cloud/tutorials/mysql/kak-ustanovit-mysql-na-ubuntu-1804)
